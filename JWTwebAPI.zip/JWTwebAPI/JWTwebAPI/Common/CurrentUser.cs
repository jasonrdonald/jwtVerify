﻿using JWTwebAPI.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace JWTwebAPI.Common
{
    public class CurrentUser : ICurrentUser
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }

        public CurrentUser(IHttpContextAccessor context)
        {
            ClaimsIdentity claimsIdentity = (ClaimsIdentity)context.HttpContext.User.Identity;
            IEnumerable<Claim> claims = claimsIdentity.Claims;
            if (claims != null && claims.Count() > 0)
            {
                string userId = claims.Where(x => x.Type.Equals(ClaimTypes.Name)).Select(x => x.Value).FirstOrDefault();
                Id = Convert.ToInt32(userId);
                mUser user = _users.Where(x => x.Id == Id).FirstOrDefault();
                FirstName = user.FirstName;
                LastName = user.LastName;
                Username = user.Username;
            }
        }
        private List<mUser> _users = new List<mUser>
        {
            new mUser { Id = 1, FirstName = "Test", LastName = "User", Username = "test", Password = "test" }
        };
    }
}
