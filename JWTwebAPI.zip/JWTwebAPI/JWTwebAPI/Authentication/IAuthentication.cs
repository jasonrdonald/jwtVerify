﻿using JWTwebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTwebAPI
{
    public interface IAuthentication
    {
        mUser Authenticate(string username, string password);
    }
}
