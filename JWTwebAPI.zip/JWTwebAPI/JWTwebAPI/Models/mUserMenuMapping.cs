﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTwebAPI.Models
{
    public class mUserMenuMapping
    {
        public mUserMenuMapping(int userID, int menuID)
        {
            UserID = userID;
            MenuID = menuID;
        }
        public int UserID { get; set; }
        public int MenuID { get; set; }
    }
}
