﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JWTwebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace JWTwebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IAuthentication _authentication;
        public LoginController(IAuthentication authentication)
        {
            _authentication = authentication;
        }

        [HttpPost]
        public IActionResult Authenticate(mLoginInput request)
        {

            if (!string.IsNullOrEmpty(request.LoginID) && !string.IsNullOrEmpty(request.Password))
            {
                mUser currentUser = _authentication.Authenticate(request.LoginID, request.Password);
                if (currentUser != null)
                {
                    return Ok(currentUser);
                }
            }
            return BadRequest("Invalid Crendentials");
        }
    }
}