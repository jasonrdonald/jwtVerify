﻿using JWTwebAPI.Authorization;
using JWTwebAPI.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace JWTwebAPI.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class DataController : ControllerBase
    {
        private readonly ICurrentUser _currentUser;

        public DataController(ICurrentUser currentUser)
        {
            _currentUser = currentUser;
        }

        [HttpGet]
        [MenuAccess(1)]
        public IActionResult Get()
        {
            return Ok($"{_currentUser.FirstName} {_currentUser.LastName} - It Works");
        }

        [HttpGet("NoAccess")]
        [MenuAccess(2)]
        public IActionResult NoAccess()
        {
            return Ok($"{_currentUser.FirstName} {_currentUser.LastName} - It Works");
        }
    }
}