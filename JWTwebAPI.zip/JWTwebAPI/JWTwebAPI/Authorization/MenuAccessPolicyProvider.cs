﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTwebAPI.Authorization
{
    public class MenuAccessPolicyProvider : IAuthorizationPolicyProvider
    {
        const string PolicyPrefix = "Menu";

        private DefaultAuthorizationPolicyProvider FallbackPolicyProvider { get; }

        public MenuAccessPolicyProvider(IOptions<AuthorizationOptions> options)
        {
            FallbackPolicyProvider = new DefaultAuthorizationPolicyProvider(options);
        }

        public Task<AuthorizationPolicy> GetPolicyAsync(string policyName)
        {
            if (policyName.StartsWith(PolicyPrefix, StringComparison.OrdinalIgnoreCase))
            {
                int menuID = Convert.ToInt32(policyName.Split('|')[1]);
                var policy = new AuthorizationPolicyBuilder();
                policy.AddRequirements(new MenuAccessRequirement(menuID));
                return Task.FromResult(policy.Build());
            }

            return Task.FromResult<AuthorizationPolicy>(null);
        }

        Task<AuthorizationPolicy> IAuthorizationPolicyProvider.GetDefaultPolicyAsync()
        {
            return FallbackPolicyProvider.GetDefaultPolicyAsync();
        }



    }
}
