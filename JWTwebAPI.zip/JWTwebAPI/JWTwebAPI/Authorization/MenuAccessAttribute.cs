﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTwebAPI.Authorization
{
    public class MenuAccessAttribute : AuthorizeAttribute
    {
        const string PolicyPrefix = "Menu";
        public int MenuID { get; set; }

        public MenuAccessAttribute(int menuID)
        {
            MenuID = menuID;
            Policy = $"{PolicyPrefix}|{MenuID}";
        }
    }
}
