﻿using JWTwebAPI.Common;
using JWTwebAPI.Models;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTwebAPI.Authorization
{
    public class MenuAccessAuthorizationHandler : AuthorizationHandler<MenuAccessRequirement>
    {
        private readonly ICurrentUser _currentUser;
        public MenuAccessAuthorizationHandler(ICurrentUser currentUser)
        {
            _currentUser = currentUser;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, MenuAccessRequirement requirement)
        {
            if (_currentUser.Id != 0)
            {
                bool hasPermission = getUserMenuPermission().Where(x => x.MenuID == requirement.MenuID).Any();
                if (hasPermission)
                {
                    context.Succeed(requirement);
                }
            }
            return Task.CompletedTask;
        }

        private List<mUserMenuMapping> getUserMenuPermission()
        {
            List<mUserMenuMapping> data = new List<mUserMenuMapping>()
            {
                new mUserMenuMapping(1,1),
                new mUserMenuMapping(2,1),
                new mUserMenuMapping(2,2),

            };
            return data.Where(x => x.UserID == _currentUser.Id).ToList();
        }
    }
}
