﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTwebAPI.Authorization
{
    public class MenuAccessRequirement : IAuthorizationRequirement
    {
        public int MenuID { get; private set; }
        public MenuAccessRequirement(int menuId)
        {
            MenuID = menuId;
        }
    }
}
